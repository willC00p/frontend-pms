import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  FaTachometerAlt,
  FaCar,
  FaUsers,
  FaEnvelope,
  FaCog
} from 'react-icons/fa';
import './sidebar.css';

const Sidebar = () => {
  const location = useLocation();

  return (
    <div className="sidebar">
      <h3>PARKING SYSTEM</h3>

      <ul className="sidebar-menu">
        <li className={location.pathname === '/' ? 'active' : ''}>
          <Link to="/">
            <FaTachometerAlt className="sidebar-icon" />
            DASHBOARD
          </Link>
        </li>
        <li className={location.pathname === '/parking-spaces' ? 'active' : ''}>
          <Link to="/parking-spaces">
            <FaCar className="sidebar-icon" />
            PARKING SPACES
          </Link>
        </li>
      </ul>

      <ul className="sidebar-menu">
        <li className={location.pathname === '/user-list' ? 'active' : ''}>
          <Link to="/user-list">
            <FaUsers className="sidebar-icon" />
            USER LIST
          </Link>
        </li>
        <li className={location.pathname === '/messages' ? 'active' : ''}>
          <Link to="/messages">
            <FaEnvelope className="sidebar-icon" />
            MESSAGES
          </Link>
        </li>
      </ul>

      <ul className="sidebar-menu">
        <li className={location.pathname === '/settings' ? 'active' : ''}>
          <Link to="/settings">
            <FaCog className="sidebar-icon" />
            SETTINGS
          </Link>
        </li>
      </ul>
    </div>
  );
};

export default Sidebar;
