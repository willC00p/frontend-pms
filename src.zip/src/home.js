import React from 'react';
import Sidebar from './sidebar';
import Dashboard from './dashboard';
import './home.css'; 

function Home() {
  return (
    <div className="home-container">
      <Sidebar />
      <Dashboard />
    </div>
  );
}

export default Home;