import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Dashboard from './dashboard';
import ParkingSpaces from './parkingspaces';
import UserList from './userlist';
import Sidebar from './sidebar';
import EditParking from './editparkingspace';

function App() {
  return (
    <Router>
      <div style={{ display: 'flex' }}>
        <Sidebar />
        <div style={{ flex: 1 }}>
          <Routes>
            <Route path="/" element={<Dashboard />} />
            <Route path="/parking-spaces" element={<ParkingSpaces />} />
            <Route path="/user-list" element={<UserList />} />
            <Route path="/edit-parking" element={<EditParking />} />
          </Routes>
        </div>
      </div>
    </Router>
  );
}

export default App;
